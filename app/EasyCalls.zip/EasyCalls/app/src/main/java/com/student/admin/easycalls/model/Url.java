package com.student.admin.easycalls.model;

class Url {

    static final String BASE_URL_NEW="http://dneers.com/easycalls/";

}
